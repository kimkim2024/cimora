"""Export selected cached PSD layer pixels; never modify source PSDs.

Requires Python 3.10+, psd-tools and Pillow. Cached pixels intentionally retain
the artwork, but do not render Photoshop layer styles or clipping stacks.
"""
import argparse
import json
from pathlib import Path

from PIL import Image
from psd_tools import PSDImage


LAYERS = {
    '欧美卡通画板 1 拷贝.psd': {
        'landscape': '0/0/0', 'landscape-blur': '0/0/1',
        'boar-rider': '0/8', 'avatar': '0/1/7',
        'coin': '0/9/6', 'gem': '0/9/13', 'key': '0/9/14',
        'chest': '0/10/4', 'knight': '0/7/2', 'witch': '0/11/2',
        'trophy': '0/7/26', 'home-icon': '0/3/8',
        'heroes-icon': '0/3/14', 'summon-icon': '0/3/15',
        'guild-icon': '0/3/16', 'mail-icon': '0/4/3',
        'shop-icon': '0/4/8', 'friends-icon': '0/4/12',
    },
    '欧美卡通画板 3.psd': {
        'activity-art': '0/0', 'potion': '0/35', 'ring': '0/36',
        'leaf': '0/33', 'purchase-skin': '0/38',
    },
    '欧美卡通画板 4.psd': {'crystal': '0/3'},
}
REFERENCES = {'主界面.png': 'home', '活动界面.png': 'activity',
              '对战界面.png': 'battle', '进入游戏.png': 'start',
              '奖励获取.png': 'reward'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    manifest = []
    for filename, selected in LAYERS.items():
        psd = PSDImage.open(args.source / filename)
        for name, path in selected.items():
            layer = psd
            for index in path.split('/'):
                layer = layer[int(index)]
            pixels = layer.topil()
            if pixels is None:
                raise ValueError(f'No cached pixels: {filename}:{path}')
            pixels.save(args.output / f'{name}.webp', lossless=True)
            manifest.append({'file': f'{name}.webp', 'source': filename,
                             'layer': path, 'name': layer.name,
                             'bbox': list(layer.bbox), 'size': list(pixels.size),
                             'method': 'cached-layer-pixels'})
    for filename, name in REFERENCES.items():
        with Image.open(args.source / filename) as pixels:
            pixels.thumbnail((1600, 900))
            pixels.convert('RGB').save(args.output / f'reference-{name}.webp', quality=88)
    (args.output / 'manifest.json').write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Exported {len(manifest)} layers and {len(REFERENCES)} references to {args.output}')


if __name__ == '__main__':
    main()
