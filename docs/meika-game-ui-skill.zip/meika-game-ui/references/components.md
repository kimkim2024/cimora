# 组件接入

将 `assets/react/` 中的两个文件复制到项目组件目录；把 `assets/media/` 的 WebP 文件复制到公开目录 `public/meika/`。`manifest.json` 可保留用于追溯。

所有组件位于带 `mk-theme` 类名的祖先节点中。主题变量定义在 `meika.css`，组件样式以 `mk-` 为前缀。组件本身不引入项目全局样式。

```tsx
import { useState } from 'react';
import { GameButton, RewardDialog, RewardItem, meikaAsset } from './components/meika';

export function Rewards() {
  const [open, setOpen] = useState(false);
  return <section className="mk-theme">
    <GameButton tone="gold" onClick={() => setOpen(true)}>查看奖励</GameButton>
    <RewardDialog open={open} onClose={() => setOpen(false)}>
      <RewardItem image={meikaAsset('crystal')} name="星芒水晶" quantity={1} />
    </RewardDialog>
  </section>;
}
```

| 组件 | 必需参数 | 可选参数与行为 |
| --- | --- | --- |
| `GameButton` | `children` | 原生 button 参数；`tone`: blue / gold，默认 blue；支持 disabled |
| `ResourceCounter` | `icon, label, value` | `onAdd`；未传入时不显示增加按钮 |
| `PlayerBadge` | `name, avatar, level, progress, power` | progress 为 0–100 的等级进度 |
| `ModeCard` | `title, subtitle, image, onClick` | `tag, progress, className`；progress 为 0–100 |
| `GameNavigation` | `items, active, onSelect` | items 包含 id/label/icon，可带 notification；label 定义导航区域名称 |
| `RewardItem` | `image, name` | `quantity`；rarity: rare / epic / legendary，默认 rare |
| `RewardDialog` | `open, onClose, children` | title 默认 REWARD；原生 dialog 提供模态焦点和 Esc 行为 |

`meikaAsset(name)` 默认返回 `/meika/${name}.webp`，当前适用于站点根路径部署。子目录或 CDN 部署时统一修改该函数与 CSS 中两处 `/meika/` 素材地址。

展示页源文件在原项目 `F:\cimorastudio\src\meika\`，路由 `/meika`。这里的余额增加、匹配、领取和导航仅作本地交互示范，不是游戏业务实现。组件库没有全局状态依赖，可以接入调用方已有业务状态。
