# 设计依据

原稿横屏尺寸均为 2436 × 1125，比例约 2.165:1。文件集包含 6 张 PNG、7 个 PSD；本版以 5 张单页 PNG 为视觉依据，从 3 个单页 PSD 提取 24 个图层。总画板和长图保留为原始来源，没有导入运行时。

## 按页面查看

- [主界面](../assets/media/reference-home.webp)：角色左、模式右；左上身份，右上资源，底部主导航。主模式卡比支线卡更宽，金色进度线细而明确。
- [活动界面](../assets/media/reference-activity.webp)：左侧纵向目录，中央人物插画，右侧道具沿斜线排列；金色主按钮在右下。
- [对战界面](../assets/media/reference-battle.webp)：蓝橙队伍区分，斜切角色列，中间 VS。当前组件包不包含完整 VS 页面，后续按需扩展。
- [进入游戏](../assets/media/reference-start.webp)：全幅角色构图，中央 Logo，蓝色透明启动按钮。当前包不包含此 Logo 或整页复刻。
- [奖励获取](../assets/media/reference-reward.webp)：模糊背景、青蓝中央光晕、大号奖励物、顶部重标题。对应 RewardDialog 和 RewardItem。

## 实现色板

以下为对照原稿后选定的工程近似值，不是 PSD 全量颜色采样结果。

| 变量 | 值 | 用途 |
| --- | --- | --- |
| `--mk-ink` | `#09152f` | 最深背景 |
| `--mk-panel` | `#17395bcc` | 透明面板 |
| `--mk-cyan` | `#91e9f4` | 选中、信息和光效 |
| `--mk-text` | `#e7f8ef` | 主文本 |
| `--mk-gold` | `#f6bd59` | 奖励与价值 |
| `--mk-orange` | `#ff8b26` | 活动标记 |
| `--mk-line` | `#9ed6e399` | 边框 |
| `--mk-purple` | `#bb65e7` | 稀有道具 |

边框以 1–2px 为主，卡片保持大面积画面。按钮可使用斜向圆角与端部星芒，避免所有容器都使用同一圆角胶囊。

## 字体

主界面 PSD 文字资源记录包含 AcuminConcept 的 Black、BlackItalic、CondensedSemibold、ExtraCondensedBold、SemiCondensedBold、WideSemibold、Medium、Regular、Semibold，以及 AdobeHeitiStd-Regular。字体文件未随设计稿提供。

当前实现使用 Impact / Arial Narrow 展示英文标题，Segoe UI / Microsoft YaHei 展示正文。系统不同会有字宽和字重差异。用户提供可使用的原字体后，再定义本地 `@font-face` 并对照调节，不把占位字体当作原版。

## 素材精度

查看 [来源清单](../assets/media/manifest.json)，每个素材记录 PSD 文件、从零计数的图层索引路径、图层名和原始 bbox。WebP 图层无损导出，保留透明度；参考图压缩至最多 1600px 宽，仅作对照。

`boar-rider`、`knight`、`witch` 为角色；`landscape` 和 `landscape-blur` 为场景；`coin`、`gem`、`key` 为资源；`crystal`、`potion`、`ring`、`leaf`、`chest`、`trophy` 为奖励或道具。其余为导航图标、活动画面与按钮底图。

CSS 光晕、边框和渐变是网页近似实现，未把所有 PS 图层效果烘焙入素材。
