---
name: cimora-art-direction
description: "Design, implement, or review Cimora Studio UI with a Zenless Zone Zero-inspired visual system: character-led composition, light gray and black structure, acid-lime accents, diagonal textures, and rounded diagonal panels. Use for its landing page, login, template gallery, creative canvas, and character or background art briefs. Extract visual principles rather than reproducing the reference site pixel for pixel."
---

# Cimora Art Direction

为 Cimora Studio 建立接近《绝区零》参考图观感、能延伸到创作工具的视觉系统。说明使用中文，界面默认英文；用户后续明确要求优先。

## 已确认方向

- 范围：宣传官网、登录/注册、模板广场、实际无限画布。
- 提炼视觉语法，使用 Cimora 的品牌、人物和布局；不是一比一复刻。
- 重点：角色展示、配色、背景。全局基调浅灰 + 黑色 + 荧光黄绿，职业可有辅助色与独立画风。
- 三职业同等重要：Anime Creator、Game Builder、Comic Artist。不强求共享世界观。
- 主职业下有细分角色，一位角色代表一个工作流。选人展示不是进入编辑器必须重复经过的步骤。
- 允许按当前任务重做布局；调用本 Skill 不代表授权重做所有页面。

## 工作流程与资料路由

1. 阅读当前页面及已有组件，明确本次是讨论、设计、实现还是评审。讨论不自动变成代码修改。
2. 首次应用或重新定调时读 [视觉图解](references/visual-language.md)，用图像查看工具打开相关参考截图。红框和语音浮层是用户标注，不属于官网设计。
3. 阅读 [页面规则](references/page-patterns.md) 中对应页面；涉及角色或场景素材时再读 [素材说明](references/art-brief.md)。
4. 以 [视觉参数](references/tokens.md) 为起点，可按项目样式方案接入 [CSS 参数](assets/cimora-tokens.css)。不为套用风格新增不必要的框架。
5. 先解决构图、阅读顺序和主操作，再补纹理、动效。素材缺失显式标为占位，不伪称成品。
6. 完成后按 [检查清单](references/review.md) 验证，只报告实际观察与测试的结果。

## 核心判断

- **构图优先**：官网人物、标题、背景带有前后关系；少量重复大形状串起页面。
- **亮色有职责**：荧光色表示品牌主动作、选择或章节重点；职业色表示身份；错误/成功独立使用语义色。
- **圆角与斜边共存**：大圆角软化斜向转折，不把所有控件裁成同一种多边形。
- **破框不破操作**：人物可以伸出容器，不能遮住文字、按钮、焦点环或制造横向滚动。
- **编辑器克制**：节点、输入框、正文平直；工作区中性色，不铺胶片带、立绘或荧光底。
- **文字可读**：大标题可粗重窄体，正文正常宽度。8°仅是旧角色选择板的轻侧向透视约束，不是全站旋转角度。
- **不冻结旧原型**：AKI/ROOK/INK、旧七角色数量、旧深色样式不是永久规范。游戏方向已为 Game Concept Visualization 与轻量 Game Asset Generation；Live2D 暂定、3D 展示待决定，不宣传为已上线能力。

## 交付边界

设计请求交付方案与素材说明；实现请求交付相关代码与验证；评审指出具体偏差。不自动修改后端、收费、身份认证或生成服务。参考图仅用于分析，不作为 Cimora 生产角色、Logo 或主视觉。用户最新确认优先于旧设计交接文档。

示例：
- “用 $cimora-art-direction 设计职业选择模块，先出方案。”
- “用 $cimora-art-direction 改造登录页，保留现有登录逻辑。”
- “用 $cimora-art-direction 设计模板广场，包含空状态。”
- “用 $cimora-art-direction 检查画布编辑器是否过度装饰。”
